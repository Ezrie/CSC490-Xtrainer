package code.main.database;

public class MySQLAdapter implements DatabaseConnectorInterface {
}
