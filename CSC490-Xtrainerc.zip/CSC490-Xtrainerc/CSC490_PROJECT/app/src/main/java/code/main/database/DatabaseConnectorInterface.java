package code.main.database;

public interface DatabaseConnectorInterface {
}
