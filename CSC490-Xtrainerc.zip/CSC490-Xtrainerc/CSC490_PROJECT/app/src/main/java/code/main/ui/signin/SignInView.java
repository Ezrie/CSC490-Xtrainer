package code.main.ui.signin;

import androidx.lifecycle.ViewModel;

public class SignInView extends ViewModel {

}
