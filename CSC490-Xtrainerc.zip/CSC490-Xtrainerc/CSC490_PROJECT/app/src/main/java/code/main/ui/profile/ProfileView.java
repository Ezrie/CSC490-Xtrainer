package code.main.ui.profile;

import androidx.lifecycle.ViewModel;

public class ProfileView extends ViewModel {

}
